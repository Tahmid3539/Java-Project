package Project;

public class Plane extends Ticket {
    private String type;
    private String airport;
    
    public Plane(String name, String destination, String type, String airport, String time, String person, double price, double rating){
        super(name, destination, time, person, price, rating);
        this.type = type;
        this.airport = airport;
    }
    
    public void setType(String type){
        this.type = type;
    }
    public void setAirport(String airport){
        this.airport = airport;
    }
    
    public String getType(){
        return this.type;
    }
    public String getAirport(){
        return this.airport;
    }
}
