package Project;

public class Hotel extends Selector {
    private int stay;
    
    public Hotel(String name, int stay, String person, double price, double rating){
        super(name, person, price, rating);
        this.stay = stay;
    }
    
    public void setStay(int stay){
        this.stay = stay;
    }
    
    public int getStay(){
        return this.stay;
    }
}
