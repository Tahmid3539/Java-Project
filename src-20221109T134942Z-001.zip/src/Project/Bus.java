package Project;

public class Bus extends Ticket {
    private String sitNum;
    private String condition;
    
    public Bus(String name, String destination, String sitNum, String condition, String time, String person, double price, double rating){
        super(name, destination, time, person, price, rating);
        this.sitNum = sitNum;
        this.condition = condition;
    }
    
    public void setSitNum(String sitNum){
        this.sitNum = sitNum;
    }
    public void setCondition(String condition){
        this.condition = condition;
    }
    
    public String getSitNum(){
        return this.sitNum;
    }
    public String getCondition(){
        return this.condition = condition;
    }
}
