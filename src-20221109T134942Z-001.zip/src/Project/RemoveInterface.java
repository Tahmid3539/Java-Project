package Project;

public interface RemoveInterface {
    public void removePackage(Package pkg);
    public void removeHotel(Hotel hotel);
    public void removePlane(Plane plane);
    public void removeBus(Bus bus);
}
