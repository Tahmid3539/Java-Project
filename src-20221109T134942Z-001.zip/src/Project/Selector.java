package Project;

public class Selector {
    private String name;
    private String person;
    private double price;
    private double rating;
    
    public Selector(String name, String person, double price, double rating){
        this.name = name;
        this.person = person;
        this.price = price;
        this.rating = rating;
    }
    
    public void setName(String name){
        this.name = name;
    }
    public void setPerson(String person){
        this.person = person;
    }
    public void setPrice(double price){
        this.price = price;
    }
    public void setRating(double rating){
        this.rating = rating;
    }
    
    public String getName(){
        return this.name;
    }
    public String getPerson(){
        return this.person;
    }
    public double getPrice(){
        return this.price;
    }
    public double getRating(){
        return this.rating;
    }
}
