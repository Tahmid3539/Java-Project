package Project;

public class Organizer implements InsertInterface, RemoveInterface {
    public Package pkg[];
    public Hotel hotel[];
    public Plane plane[];
    public Bus bus[];
    
    public Organizer(int sizePkg, int sizeHotel, int sizePlane, int sizeBus){
        pkg = new Package[sizePkg];
        hotel = new Hotel[sizeHotel];
        plane = new Plane[sizePlane];
        bus = new Bus[sizeBus];
    }
    
    public void insertPackage(Package pkg){
        int flag = 0;
        for(int i = 0; i<this.pkg.length; i++){
            if(this.pkg[i] == null){
                this.pkg[i] = pkg;
                flag = 1;
                break;
            }
        }
        if(flag == 1){
            System.out.println("Package inseted");
        }
        else{
            System.out.println("Failed to insert package");
        }
    }
    public void insertHotel(Hotel hotel){
        for(int i = 0; i<this.hotel.length; i++){
            if(this.hotel[i] == null){
                this.hotel[i] = hotel;
            }
        }
    }
    public void insertPlane(Plane plane){
        for(int i = 0; i<this.plane.length; i++){
            if(this.plane[i] == null){
                this.plane[i] = plane;
            }
        }
    }
    public void insertBus(Bus bus){
        for(int i = 0; i<this.bus.length; i++){
            if(this.bus[i] == null){
                this.bus[i] = bus;
            }
        }
    }
    
    public void removePackage(Package pkg){
        for(int i = 0; i<this.pkg.length; i++){
            if(this.pkg[i] == pkg){
                this.pkg[i] = null;
            }
        }
    }
    public void removeHotel(Hotel hotel){
        for(int i = 0; i<this.hotel.length; i++){
            if(this.hotel[i] == hotel){
                this.hotel[i] = hotel;
            }
        }
    }
    public void removePlane(Plane plane){
        for(int i = 0; i<this.plane.length; i++){
            if(this.plane[i] == plane){
                this.plane[i] = null;
            }
        }
    }
    public void removeBus(Bus bus){
        for(int i = 0; i<this.bus.length; i++){
            if(this.bus[i] == bus){
                this.bus[i] = null;
            }
        }
    }
}
