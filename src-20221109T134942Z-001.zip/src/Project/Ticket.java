package Project;

public class Ticket extends Selector {
    private String destination;
    private String time;
    
    public Ticket(String name, String destination, String time, String person, double price, double rating){
        super(name, person, price, rating);
        this.destination = destination;
        this.time = time;
    }
    
    public void setDestinatin(String destination){
        this.destination = destination;
    }
    public void setTime(String time){
        this.time = time;
    }
    
    
    public String getDestination(String destination){
        return this.destination;
    }
    public String getTime(String time){
        return this.time;
    }
}
