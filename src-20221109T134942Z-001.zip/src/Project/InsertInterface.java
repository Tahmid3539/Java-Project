package Project;

public interface InsertInterface {
    public void insertPackage(Package pkg);
    public void insertHotel(Hotel hotel);
    public void insertPlane(Plane plane);
    public void insertBus(Bus bus);
}
