package Project;

public class Package extends Selector {
    private int day;
    
    public Package(String name, int day, String person, double price, double rating){
        super(name, person, price, rating);
        this.day = day;
    }
    
    public void setDay(int day){
        this.day = day;
    }
    
    public int getDay(){
        return this.day;
    }
}
